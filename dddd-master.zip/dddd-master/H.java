public class H {
    public static void main(final String[] args) {
        System.out.println("Hello World");
        System.out.println("中文");
    }
} 

//kkk
