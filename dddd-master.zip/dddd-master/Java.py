print("java")
