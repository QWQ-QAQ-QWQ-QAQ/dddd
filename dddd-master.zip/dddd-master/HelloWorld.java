﻿public class HelloWorld {
    public  void helloWorld(){
        System.out.println("Hello world!");
	    System.out.println("中文");
    }
}